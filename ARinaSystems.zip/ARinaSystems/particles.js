<div class="hero">
  <div class="particles"></div>
  <h1>Welcome to Arina Systems</h1>
  <p>We build future-ready tech solutions.</p>
</div>
